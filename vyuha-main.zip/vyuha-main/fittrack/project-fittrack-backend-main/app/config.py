import os
from datetime import timedelta

class Config:
    DEBUG = True
    SECRET_KEY = "supersecretkey"
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:1234@localhost/fittrack"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    JWT_SECRET_KEY = "supersecretkey"  # required
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=1)  # ✅ Set token to expire after 1 day
