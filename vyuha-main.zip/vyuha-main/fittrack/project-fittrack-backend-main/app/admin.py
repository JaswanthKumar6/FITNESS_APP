from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import WorkoutType, User, Workout
from app import db
from sqlalchemy import func

admin_bp = Blueprint('admin', __name__, url_prefix="/api/admin")

# ----------------------------
# Admin-only access decorator
# ----------------------------
def admin_required(func):
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        if not user or not user.is_admin:
            return jsonify({"error": "Admins only"}), 403
        return func(*args, **kwargs)
    return wrapper

# ----------------------------
# GET all workout types
# ----------------------------
@admin_bp.route('/workout-types', methods=['GET'])
@jwt_required()
@admin_required
def get_workout_types():
    types = WorkoutType.query.all()
    return jsonify([{"name": t.name} for t in types]), 200

# ----------------------------
# POST: Add new workout type
# ----------------------------
@admin_bp.route('/workout-types', methods=['POST'])
@jwt_required()
@admin_required
def add_workout_type():
    data = request.get_json()
    name = data.get("name", "").strip().capitalize()

    if not name:
        return jsonify({"error": "Name is required"}), 400

    if WorkoutType.query.filter(func.lower(WorkoutType.name) == name.lower()).first():
        return jsonify({"error": "Type already exists"}), 409

    try:
        new_type = WorkoutType(name=name)
        db.session.add(new_type)
        db.session.commit()
        return jsonify({"message": "Workout type added", "name": name}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Database error", "details": str(e)}), 500

# ----------------------------
# DELETE: Remove workout type
# ----------------------------
@admin_bp.route('/workout-types/<string:name>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_workout_type(name):
    workout_type = WorkoutType.query.filter(func.lower(WorkoutType.name) == name.lower()).first()

    if not workout_type:
        return jsonify({"error": "Type not found"}), 404

    try:
        db.session.delete(workout_type)
        db.session.commit()
        return jsonify({"message": "Workout type deleted"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Delete failed", "details": str(e)}), 500


# ----------------------------
# GET: All users with stats
# ----------------------------
@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@admin_required
def get_users():
    try:
        users = db.session.query(
            User,
            func.count(Workout.id).label('workouts_count'),
            func.sum(Workout.calories).label('total_calories'),
            func.sum(Workout.duration).label('total_duration')
        ).outerjoin(Workout, User.id == Workout.user_id).group_by(User.id).all()

        result = []
        for user, workouts_count, total_calories, total_duration in users:
            user_data = {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "name": user.name,
                "is_admin": user.is_admin,
                "created_at": user.created_at.strftime("%Y-%m-%d") if user.created_at else None,
                "workouts_count": workouts_count or 0,
                "total_calories": total_calories or 0,
                "total_duration": total_duration or 0
            }
            result.append(user_data)

        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": "Failed to fetch users", "details": str(e)}), 500


# ----------------------------
# PATCH: Toggle user admin status
# ----------------------------
@admin_bp.route('/users/<int:user_id>/toggle-admin', methods=['PATCH'])
@jwt_required()
@admin_required
def toggle_user_admin(user_id):
    try:
        user = User.query.get_or_404(user_id)
        user.is_admin = not user.is_admin
        db.session.commit()
        return jsonify({
            "message": f"User admin status updated",
            "is_admin": user.is_admin
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to update user", "details": str(e)}), 500


# ----------------------------
# DELETE: Delete user
# ----------------------------
@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_user(user_id):
    try:
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        return jsonify({"message": "User deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to delete user", "details": str(e)}), 500


# ----------------------------
# GET: Platform statistics
# ----------------------------
@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
@admin_required
def get_platform_stats():
    try:
        from datetime import datetime, timedelta
        
        # Total stats
        total_users = User.query.count()
        total_workouts = Workout.query.count()
        total_calories = db.session.query(func.sum(Workout.calories)).scalar() or 0
        total_duration = db.session.query(func.sum(Workout.duration)).scalar() or 0
        
        # Recent workouts (last 7 days)
        week_ago = datetime.utcnow() - timedelta(days=7)
        recent_workouts = Workout.query.filter(Workout.date >= week_ago.strftime("%Y-%m-%d")).count()
        
        stats = {
            "total_users": total_users,
            "total_workouts": total_workouts,
            "total_calories": total_calories,
            "total_duration": total_duration,
            "recent_workouts": recent_workouts
        }
        
        return jsonify(stats), 200
    except Exception as e:
        return jsonify({"error": "Failed to fetch stats", "details": str(e)}), 500
