from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from openai import OpenAI
import os

ai_bp = Blueprint("ai", __name__)

# Initialize OpenAI client using default environment variable
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

@ai_bp.route("/generate-tip", methods=["POST"])
@jwt_required()
def generate_tip():
    user_id = get_jwt_identity()
    data = request.get_json()
    summary = data.get("summary", "")

    if not summary:
        return jsonify({"error": "Workout summary is required"}), 400

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful fitness coach."},
                {"role": "user", "content": f"Here is my recent workout summary:\n{summary}\nGive me one useful fitness tip based on that."}
            ]
        )

        # ✅ The newer response format
        tip = response.choices[0].message.content.strip()

        return jsonify({"tip": tip}), 200

    except Exception as e:
        print("🔥 Error in /generate-tip:", e)  # Always useful for debugging
        return jsonify({"error": str(e)}), 500
