from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import User
from app import db

user_bp = Blueprint('user', __name__)

@user_bp.route('/profile', methods=['GET', 'PUT'])
@jwt_required()
def user_profile():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)

    if not user:
        return jsonify({"msg": "User not found"}), 404

    if request.method == "GET":
        return jsonify({
            "name": user.name,
            "email": user.email,
            "joined": user.created_at.strftime("%Y-%m-%d") if user.created_at else None,
            "weight": user.weight,
            "height": user.height,
            "age": user.age,
            "goal": user.goal,
        })

    elif request.method == "PUT":
        data = request.get_json()

        user.name = data.get("name", user.name)
        user.weight = data.get("weight", user.weight)
        user.height = data.get("height", user.height)
        user.age = data.get("age", user.age)
        user.goal = data.get("goal", user.goal)

        db.session.commit()

        return jsonify({
            "name": user.name,
            "email": user.email,
            "joined": user.created_at.strftime("%Y-%m-%d") if user.created_at else None,
            "weight": user.weight,
            "height": user.height,
            "age": user.age,
            "goal": user.goal,
        })
