from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
import os
import time
from werkzeug.utils import secure_filename

audio_bp = Blueprint('audio', __name__)

@audio_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload_audio():
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided'}), 400

    audio_file = request.files['audio']
    if audio_file.filename == '':
        return jsonify({'error': 'Empty filename'}), 400

    filename = secure_filename(f"recording-{int(time.time())}.webm")
    upload_folder = current_app.config['UPLOAD_FOLDER']
    filepath = os.path.join(upload_folder, filename)

    try:
        audio_file.save(filepath)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

    file_url = f"/uploads/{filename}"
    full_url = f"{request.host_url.rstrip('/')}{file_url}"

    return jsonify({
        "message": "Audio uploaded successfully",
        "file_url": file_url,
        "full_url": full_url  # ← frontend can use this directly
    }), 200
