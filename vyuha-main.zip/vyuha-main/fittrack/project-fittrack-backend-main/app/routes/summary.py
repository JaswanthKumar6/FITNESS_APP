from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import Workout, db
from datetime import datetime, timedelta
from collections import defaultdict

summary_bp = Blueprint("summary", __name__, url_prefix="/api/summary")

def parse_date(date_str):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except Exception:
        return None

@summary_bp.route("/chart", methods=["GET"])
@jwt_required()
def workout_summary_chart():
    user_id = get_jwt_identity()
    view = request.args.get("view", "weekly")

    # Validate view
    if view not in ["weekly", "monthly"]:
        return jsonify({"error": "Invalid view type"}), 400

    # Get cutoff date
    days = 7 if view == "weekly" else 30
    cutoff_date = datetime.utcnow() - timedelta(days=days)

    # Query relevant workouts only
    recent_workouts = (
        db.session.query(Workout)
        .filter(Workout.user_id == user_id, Workout.date >= cutoff_date.strftime("%Y-%m-%d"))
        .all()
    )

    # Group and summarize
    summary = defaultdict(lambda: {"total_duration": 0, "total_calories": 0})

    for workout in recent_workouts:
        date_obj = parse_date(workout.date)
        if date_obj:
            date_str = date_obj.strftime("%Y-%m-%d")
            summary[date_str]["total_duration"] += workout.duration or 0
            summary[date_str]["total_calories"] += workout.calories or 0

    # Prepare chart data
    chart_data = [
        {
            "date": date,
            "total_duration": values["total_duration"],
            "total_calories": values["total_calories"]
        }
        for date, values in sorted(summary.items())
    ]

    return jsonify(chart_data), 200
