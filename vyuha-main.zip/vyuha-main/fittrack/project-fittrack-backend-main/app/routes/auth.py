# app/routes/auth.py

from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token
from app.models import User
from app import db
from sqlalchemy import text

auth_bp = Blueprint('auth', __name__)

# ✅ TEMPORARY DB CHECK ROUTE
@auth_bp.route("/test-db", methods=["GET"])
def test_db():
    try:
        db.session.execute(text("SELECT 1"))
        return jsonify({"db": "connected ✅"}), 200
    except Exception as e:
        return jsonify({"db": "error ❌", "details": str(e)}), 500


# ✅ REGISTER ROUTE
@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    if not username or not email or not password:
        return jsonify({"error": "Username, email, and password required"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already in use"}), 409

    if User.query.filter_by(username=username).first():
        return jsonify({"error": "Username already taken"}), 409

    hashed_password = generate_password_hash(password)
    new_user = User(username=username, email=email, password=hashed_password)

    try:
        db.session.add(new_user)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Database error", "details": str(e)}), 500

    return jsonify({"msg": "User registered successfully"}), 201

# ✅ LOGIN ROUTE
@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    user = User.query.filter_by(email=email).first()

    if user and check_password_hash(user.password, password):
        access_token = create_access_token(identity=str(user.id))
        return jsonify(
            access_token=access_token,
            user={
                "id": user.id,
                "email": user.email,
                "username": user.username,
                "is_admin": user.is_admin
            }
        ), 200

    return jsonify(msg="Invalid credentials"), 401
