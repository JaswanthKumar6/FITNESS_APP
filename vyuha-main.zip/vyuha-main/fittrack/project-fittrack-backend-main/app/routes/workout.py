from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import Workout, WorkoutType
from app import db
from sqlalchemy import func
from datetime import datetime, timedelta

workout_bp = Blueprint("workout", __name__)


# ----------------------------
# Log a new workout (POST + OPTIONS)
# ----------------------------
@workout_bp.route('/', methods=['POST', 'OPTIONS'])
@jwt_required()
def create_workout():
    if request.method == 'OPTIONS':
        return '', 200

    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    try:
        data = request.get_json(force=True)

        required_fields = ["date", "type", "duration", "calories"]
        if not all(field in data for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400

        workout = Workout(
            user_id=user_id,
            date=data["date"],
            type=data["type"],
            duration=data["duration"],
            calories=data["calories"],
            note=data.get("note"),
            memo_path=data.get("audioMemo")
        )

        db.session.add(workout)
        db.session.commit()
        return jsonify({"msg": "Workout logged successfully"}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to log workout", "details": str(e)}), 400


# ----------------------------
# Get all workouts
# ----------------------------
@workout_bp.route('/', methods=['GET'])
@jwt_required()
def get_all_workouts():
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    workouts = Workout.query.filter_by(user_id=user_id).order_by(Workout.date.desc()).all()

    result = [
        {
            "id": w.id,
            "date": w.date if isinstance(w.date, str) else w.date.strftime("%Y-%m-%d"),
            "type": w.type,
            "duration": w.duration,
            "calories": w.calories,
            "audioMemo": w.memo_path
        }
        for w in workouts
    ]

    return jsonify(result), 200


# ----------------------------
# Update a workout
# ----------------------------
@workout_bp.route('/<int:workout_id>', methods=['PUT'])
@jwt_required()
def update_workout(workout_id):
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    data = request.get_json()

    workout = Workout.query.get_or_404(workout_id)

    if workout.user_id != user_id:
        return jsonify({"error": "Unauthorized"}), 403

    workout.type = data.get("type", workout.type)
    workout.date = data.get("date", workout.date)
    workout.duration = data.get("duration", workout.duration)
    workout.calories = data.get("calories", workout.calories)
    workout.memo_path = data.get("audioMemo", workout.memo_path)
    workout.note = data.get("note", workout.note)

    try:
        db.session.commit()
        return jsonify({"msg": "Workout updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to update workout", "details": str(e)}), 500


# ----------------------------
# Get workout count
# ----------------------------
@workout_bp.route('/count', methods=['GET'])
@jwt_required()
def get_workout_count():
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    count = Workout.query.filter_by(user_id=user_id).count()
    return jsonify({"total_workouts": count}), 200


# ----------------------------
# Get workout history
# ----------------------------
@workout_bp.route("/history", methods=["GET"])
@jwt_required()
def workout_history():
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    workouts = Workout.query.filter_by(user_id=user_id).order_by(Workout.date.desc()).all()

    history = [
        {
            "date": w.date if isinstance(w.date, str) else w.date.strftime("%Y-%m-%d"),
            "type": w.type,
            "duration": w.duration,
            "calories": w.calories,
            "audioMemo": w.memo_path
        }
        for w in workouts
    ]

    return jsonify(history), 200


# ----------------------------
# Workout Stats for Chart
# ----------------------------
@workout_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_workout_stats():
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    view = request.args.get("view", "weekly")

    try:
        now = datetime.utcnow()

        if view == "daily":
            since = now - timedelta(days=1)
        elif view == "weekly":
            since = now - timedelta(days=7)
        elif view == "monthly":
            since = now - timedelta(days=30)
        else:
            return jsonify({"error": "Invalid view"}), 400

        stats = (
            db.session.query(
                Workout.type,
                func.sum(Workout.duration).label("totalDuration"),
                func.sum(Workout.calories).label("totalCalories"),
                func.count().label("count")
            )
            .filter(
                Workout.user_id == user_id,
                Workout.date >= since.strftime("%Y-%m-%d")
            )
            .group_by(Workout.type)
            .all()
        )

        result = [
            {
                "type": row.type,
                "totalDuration": int(row.totalDuration or 0),
                "totalCalories": int(row.totalCalories or 0),
                "count": int(row.count)
            }
            for row in stats
        ]

        return jsonify(result), 200

    except Exception as e:
        return jsonify({"error": "Failed to fetch stats", "details": str(e)}), 500


# ----------------------------
# Get workout types (open)
# ----------------------------
@workout_bp.route('/workout-types', methods=['GET'])
def get_workout_types():
    try:
        types = WorkoutType.query.all()
        return jsonify([t.name for t in types]), 200
    except Exception as e:
        return jsonify({"error": "Failed to fetch types", "details": str(e)}), 500


# ----------------------------
# Add workout type
# ----------------------------
@workout_bp.route('/workout-types', methods=['POST'])
def add_workout_type():
    try:
        data = request.get_json(force=True)

        name = data.get("name", "").strip()
        if not name:
            return jsonify({"error": "Name is required"}), 400

        if WorkoutType.query.filter_by(name=name).first():
            return jsonify({"error": "Type already exists"}), 409

        new_type = WorkoutType(name=name)
        db.session.add(new_type)
        db.session.commit()
        return jsonify({"msg": "Workout type added", "name": name}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to add workout type", "details": str(e)}), 500


# ----------------------------
# Delete workout type
# ----------------------------
@workout_bp.route('/workout-types/<string:name>', methods=['DELETE'])
def delete_workout_type(name):
    try:
        type_obj = WorkoutType.query.filter_by(name=name).first()
        if not type_obj:
            return jsonify({"error": "Type not found"}), 404

        db.session.delete(type_obj)
        db.session.commit()
        return jsonify({"msg": f"Workout type '{name}' deleted"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to delete workout type", "details": str(e)}), 500


# ----------------------------
# Delete a specific workout
# ----------------------------
@workout_bp.route('/<int:workout_id>', methods=['DELETE'])
@jwt_required()
def delete_workout(workout_id):
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    workout = Workout.query.get_or_404(workout_id)

    if workout.user_id != user_id:
        return jsonify({"error": "Unauthorized"}), 403

    try:
        db.session.delete(workout)
        db.session.commit()
        return jsonify({"message": "Workout deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Failed to delete workout", "details": str(e)}), 500


# ----------------------------
# Clear all workouts
# ----------------------------
@workout_bp.route('/clear', methods=['DELETE'])
@jwt_required()
def clear_all_workouts():
    user_id = get_jwt_identity()
    try:
        user_id = int(user_id) if user_id is not None else None
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid user identity"}), 401
    workouts = Workout.query.filter_by(user_id=user_id).all()

    for workout in workouts:
        db.session.delete(workout)

    db.session.commit()
    return jsonify({"message": "All workouts deleted"}), 200
