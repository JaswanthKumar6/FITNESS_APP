from flask import Flask, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from dotenv import load_dotenv
from flask_migrate import Migrate
import os

# Initialize extensions
db = SQLAlchemy()
jwt = JWTManager()
migrate = Migrate()

def create_app():
    load_dotenv()

    app = Flask(__name__)

    # Static folder for audio uploads
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    # CORS setup
    CORS(app, resources={r"/api/*": {"origins": "http://localhost:5173"}}, supports_credentials=True)

    # Load configuration from .env with safe fallback
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        sqlite_path = os.path.join(os.getcwd(), 'fittrack.db')
        database_url = f"sqlite:///{sqlite_path}"
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    app.config['SECRET_KEY'] = os.getenv("SECRET_KEY", "supersecretkey")
    app.config['JWT_SECRET_KEY'] = os.getenv("JWT_SECRET_KEY", "another_super_secret")
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER  # 📁 For storing audio files

    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    migrate.init_app(app, db)

    # ✅ Register Blueprints
    from app.routes.auth import auth_bp
    from app.routes.user import user_bp
    from app.routes.workout import workout_bp
    from app.routes.ai_routes import ai_bp
    from app.routes.summary import summary_bp
    from app.admin import admin_bp
    from app.routes.audio import audio_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(user_bp, url_prefix="/api/user")
    app.register_blueprint(workout_bp, url_prefix="/api/workout")
    app.register_blueprint(ai_bp, url_prefix="/api/ai")
    # summary and admin blueprints already define their own url_prefix
    app.register_blueprint(summary_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(audio_bp, url_prefix="/api/audio")

    # ✅ Ensure tables exist (helpful for first-run with SQLite fallback)
    with app.app_context():
        db.create_all()

    # ✅ Serve uploaded audio files
    @app.route('/uploads/<filename>')
    def uploaded_file(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    # ✅ 404 Error Handler
    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Route not found"}), 404

    return app
