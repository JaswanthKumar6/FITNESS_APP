from app import db
from datetime import datetime


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    is_admin = db.Column(db.Boolean, default=False)
    # Profile Fields
    name = db.Column(db.String(150))
    weight = db.Column(db.String(10))
    height = db.Column(db.String(10))
    age = db.Column(db.String(10))
    goal = db.Column(db.String(100))

    # ✅ Admin flag (already defined above)

    # Relationship
    workouts = db.relationship('Workout', back_populates='user', cascade="all, delete")

    def to_dict(self):
        return {
            "name": self.name or self.username,
            "email": self.email,
            "joined": self.created_at.strftime("%Y-%m-%d") if self.created_at else None,
            "weight": self.weight,
            "height": self.height,
            "age": self.age,
            "goal": self.goal,
            "is_admin": self.is_admin,
        }


class Workout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    # ⚠️ This is stored as a string now
    date = db.Column(db.String(20), nullable=False)

    type = db.Column(db.String(50))
    duration = db.Column(db.Integer)   # in minutes
    calories = db.Column(db.Integer)

    # Optional profile snapshot
    weight = db.Column(db.String(10))
    height = db.Column(db.String(10))
    age = db.Column(db.String(5))
    goal = db.Column(db.String(50))

    # Optional Notes
    memo_path = db.Column(db.String(255), nullable=True)
    audio_note = db.Column(db.Text, nullable=True)
    note = db.Column(db.Text, nullable=True)

    user = db.relationship('User', back_populates='workouts')


class WorkoutType(db.Model):
    __tablename__ = "workout_types"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name
        }
