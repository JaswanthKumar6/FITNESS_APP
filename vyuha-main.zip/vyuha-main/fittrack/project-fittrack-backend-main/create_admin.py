#!/usr/bin/env python3
"""
Script to create an admin user for testing purposes
"""

from app import create_app, db
from app.models import User
from werkzeug.security import generate_password_hash

def create_admin_user():
    app = create_app()
    
    with app.app_context():
        # Check if admin already exists
        admin = User.query.filter_by(email="admin@fittrack.com").first()
        if admin:
            print("Admin user already exists!")
            return
        
        # Create admin user
        admin_user = User(
            username="admin",
            email="admin@fittrack.com",
            password=generate_password_hash("admin123"),
            is_admin=True,
            name="Admin User"
        )
        
        try:
            db.session.add(admin_user)
            db.session.commit()
            print("✅ Admin user created successfully!")
            print("Email: admin@fittrack.com")
            print("Password: admin123")
        except Exception as e:
            print(f"❌ Error creating admin user: {e}")
            db.session.rollback()

if __name__ == "__main__":
    create_admin_user() 