import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import WorkoutLog from './pages/WorkoutLog';
import Profile from './pages/Profile';
import WorkoutHistory from '@/pages/WorkoutHistory';
import AdminDashboard from './pages/AdminDashboard';
import Homepage from './pages/Homepage';
import Layout from './components/Layout'; // ✅ Assumes you have a Layout component
import WorkoutSummaryChart from "./components/WorkoutSummaryChart"; // adjust path if needed

const AppRoutes = () => {
  const isAdmin = localStorage.getItem('role') === 'admin';

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/log-workout" element={<WorkoutLog />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/history" element={<WorkoutHistory />} />
        <Route path="/summary" element={<WorkoutSummaryChart />} />

        {/* ✅ Admin Panel with Theme Support via Layout */}
        <Route
          path="/admin"
          element={
            isAdmin ? (
              <Layout>
                <AdminDashboard />
              </Layout>
            ) : (
              <Navigate to="/dashboard" replace />
            )
          }
        />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
};

export default AppRoutes;
