import { useState, useRef, useEffect } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import axios from "axios";
import Lottie from "lottie-react";
import API_BASE_URL from "../config";

import runningAnimation from "../animations/running.json";
import cyclingAnimation from "../animations/cycling.json";
import yogaAnimation from "../animations/yoga.json";
import strengthAnimation from "../animations/strength.json";
import swimmingAnimation from "../animations/swimming.json";
import hiitAnimation from "../animations/hiit.json";
import pilatesAnimation from "../animations/pilates.json";
import hikingAnimation from "../animations/hiking.json";
import danceAnimation from "../animations/dance.json";

type WorkoutType = 'Running' | 'Cycling' | 'Yoga' | 'Strength' | 'Swimming' | 'HIIT' | 'Pilates' | 'Hiking' | 'Dance';

const workoutDisplayMap: Record<WorkoutType, string> = {
  Running: "🏃‍♂️ Running",
  Cycling: "🚴‍♀️ Cycling",
  Yoga: "🧘 Yoga",
  Strength: "🏋️‍♂️ Strength",
  Swimming: "🏊 Swimming",
  HIIT: "🔥 HIIT",
  Pilates: "🧘‍♀️ Pilates",
  Hiking: "🥾 Hiking",
  Dance: "💃 Dance"
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const workoutTypes: { label: WorkoutType; animation: any }[] = [
  { label: "Running", animation: runningAnimation },
  { label: "Cycling", animation: cyclingAnimation },
  { label: "Yoga", animation: yogaAnimation },
  { label: "Strength", animation: strengthAnimation },
  { label: "Swimming", animation: swimmingAnimation },
  { label: "HIIT", animation: hiitAnimation },
  { label: "Pilates", animation: pilatesAnimation },
  { label: "Hiking", animation: hikingAnimation },
  { label: "Dance", animation: danceAnimation },
];

const WorkoutLog = () => {
  const navigate = useNavigate();
  const audioInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({
    date: "",
    type: "",
    duration: "",
    calories: "",
    audio_memo_url: "",
  });

  const [success, setSuccess] = useState(false);
  const [trackers, setTrackers] = useState<Record<WorkoutType, number>>({} as Record<WorkoutType, number>);

  useEffect(() => {
    const savedTrackers = JSON.parse(localStorage.getItem("trackers") || "{}");
    if (Object.keys(savedTrackers).length > 0) {
      setTrackers(savedTrackers);
    } else {
      const initial = workoutTypes.reduce((acc, w) => {
        acc[w.label] = 0;
        return acc;
      }, {} as Record<WorkoutType, number>);
      setTrackers(initial);
    }
  }, []);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleAudioUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const audioUrl = URL.createObjectURL(file);
      setForm((prev) => ({ ...prev, audio_memo_url: audioUrl }));
    }
  };

  const resetForm = () => {
    setForm({
      date: "",
      type: "",
      duration: "",
      calories: "",
      audio_memo_url: "",
    });
    if (audioInputRef.current) {
      audioInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const token = localStorage.getItem("token");
    if (!token) {
      alert("You are not logged in. Please log in first.");
      navigate("/login");
      return;
    }

    const newWorkout = {
      date: form.date,
      type: form.type,
      duration: parseInt(form.duration),
      calories: parseInt(form.calories),
      audioMemo: form.audio_memo_url,
    };

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/workout/`,
        newWorkout,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.status === 201) {
        const updatedTrackers = {
          ...trackers,
          [form.type as WorkoutType]: (trackers[form.type as WorkoutType] || 0) + 1,
        };
        setTrackers(updatedTrackers);
        localStorage.setItem("trackers", JSON.stringify(updatedTrackers));

        setSuccess(true);
        resetForm();

        setTimeout(() => {
          setSuccess(false);
          navigate("/dashboard");
        }, 1500);
      }
    } catch (error) {
      console.error("Failed to log workout:", error);
      if (axios.isAxiosError(error) && error.response?.status === 401) {
        alert("Session expired. Please log in again.");
        navigate("/login");
      } else {
        alert("Failed to log workout. Please try again.");
      }
    }
  };

  return (
    <Layout>
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-200 via-gray-100 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-4">
        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-2xl border border-gray-300 dark:border-gray-700 w-full max-w-2xl">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-6">
            Log Your Workout
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
            {workoutTypes.map(({ label, animation }) => (
              <div
                key={label}
                className="flex flex-col items-center bg-indigo-100 dark:bg-indigo-800 text-indigo-800 dark:text-white px-3 py-2 rounded-2xl"
              >
                <div className="w-12 h-12">
                  <Lottie animationData={animation} loop={true} />
                </div>
                <p className="text-xs mt-1 text-center font-semibold">
                  {workoutDisplayMap[label]}: {trackers[label] || 0}
                </p>
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Date
              </label>
              <input
                type="date"
                id="date"
                name="date"
                value={form.date}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
              />
            </div>

            <div>
              <label htmlFor="type" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Workout Type
              </label>
              <select
                id="type"
                name="type"
                value={form.type}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
              >
                <option value="">Select type</option>
                {workoutTypes.map(({ label }) => (
                  <option key={label} value={label}>
                    {workoutDisplayMap[label]}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="duration" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Duration (minutes)
                </label>
                <input
                  type="number"
                  id="duration"
                  name="duration"
                  value={form.duration}
                  onChange={handleChange}
                  required
                  min="1"
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
                />
              </div>

              <div>
                <label htmlFor="calories" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Calories Burned
                </label>
                <input
                  type="number"
                  id="calories"
                  name="calories"
                  value={form.calories}
                  onChange={handleChange}
                  required
                  min="0"
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label htmlFor="audio" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Upload Audio Memo (optional)
              </label>
              <input
                type="file"
                id="audio"
                accept="audio/*"
                ref={audioInputRef}
                onChange={handleAudioUpload}
                className="w-full px-2 py-1 bg-white dark:bg-gray-700 text-gray-800 dark:text-white"
              />
              {form.audio_memo_url && (
                <audio controls className="mt-2 w-full bg-white dark:bg-gray-800 rounded">
                  <source src={form.audio_memo_url} />
                  Your browser does not support the audio element.
                </audio>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 rounded-lg bg-indigo-600 text-white font-semibold hover:bg-indigo-700 transition duration-200"
            >
              Log Workout
            </button>

            {success && (
              <p className="text-green-600 dark:text-green-400 text-center mt-2">
                Workout logged successfully!
              </p>
            )}
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default WorkoutLog;
