import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });

  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    try {
      const response = await fetch("http://localhost:8000/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      console.log("Status:", response.status);
      console.log("Response data:", data);

      if (response.status === 200 || response.status === 201) {
        alert("Registered successfully!");
        navigate("/login");
      } else {
        setError(data.msg || "Registration failed");
      }
    } catch (err) {
      console.error("Register Error:", err);
      setError("Server error");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-800 via-sky-700 to-cyan-600 px-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white/10 backdrop-blur-md p-8 rounded-2xl shadow-2xl w-full max-w-md text-white border border-white/20"
      >
        <h2 className="text-3xl font-extrabold mb-6 text-center tracking-wide">
          Create an Account
        </h2>

        {error && (
          <p className="bg-red-100 text-red-700 p-2 mb-4 rounded text-sm text-center animate-pulse">
            {error}
          </p>
        )}

        <input
          type="text"
          name="username"
          placeholder="Username"
          className="mb-4 w-full px-4 py-3 rounded-lg bg-white/20 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-white focus:bg-white/30"
          value={formData.username}
          onChange={handleChange}
          required
        />

        <input
          type="email"
          name="email"
          placeholder="Email"
          className="mb-4 w-full px-4 py-3 rounded-lg bg-white/20 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-white focus:bg-white/30"
          value={formData.email}
          onChange={handleChange}
          required
        />

        <input
          type="password"
          name="password"
          placeholder="Password"
          className="mb-6 w-full px-4 py-3 rounded-lg bg-white/20 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-white focus:bg-white/30"
          value={formData.password}
          onChange={handleChange}
          required
        />

        <button
          type="submit"
          className="w-full py-3 bg-white text-blue-800 font-bold rounded-lg hover:bg-blue-100 transition-all duration-200 shadow-lg"
        >
          Register
        </button>

        <p className="mt-4 text-sm text-center">
          Already have an account?{" "}
          <Link
            to="/login"
            className="text-white font-semibold underline hover:text-gray-200"
          >
            Log in
          </Link>
        </p>
      </form>
    </div>
  );
};

export default Register;
