import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    try {
      const res = await axios.post("http://localhost:8000/api/auth/login", {
        email,
        password,
      });

      const token = res.data.access_token;
      const user = res.data.user;

      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      
      // Set admin role if user is admin
      if (user.is_admin) {
        localStorage.setItem("role", "admin");
      }

      navigate("/dashboard");
    } catch (err) {
      console.error("Login error:", err);
      if (axios.isAxiosError(err)) {
        const errorMessage = err.response?.data?.message || "Login failed. Please check your credentials.";
        setError(errorMessage);
      } else {
        setError("An unexpected error occurred. Please try again.");
      }
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-800 via-sky-700 to-cyan-600">
      <form
        onSubmit={handleSubmit}
        className="bg-white/10 backdrop-blur-md p-8 rounded-2xl shadow-2xl w-full max-w-md text-white border border-white/20"
      >
        <h2 className="text-3xl font-extrabold mb-6 text-center tracking-wide">
          Welcome Back 👋
        </h2>

        {error && (
          <p className="bg-red-100 text-red-700 p-2 mb-4 rounded text-sm text-center animate-pulse">
            {error}
          </p>
        )}

        <div className="mb-5">
          <label className="block mb-2 text-sm font-medium">Email</label>
          <input
            type="email"
            autoFocus
            className="w-full px-4 py-3 rounded-lg bg-white/20 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-white focus:bg-white/30"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="mb-6">
          <label className="block mb-2 text-sm font-medium">Password</label>
          <input
            type="password"
            className="w-full px-4 py-3 rounded-lg bg-white/20 text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-white focus:bg-white/30"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full py-3 bg-white text-blue-800 font-bold rounded-lg hover:bg-blue-100 transition-all duration-200 shadow-lg"
        >
          Log In
        </button>

        {/* 👇 Register Link */}
        <p className="mt-4 text-sm text-center">
          Don't have an account?{" "}
          <Link
            to="/register"
            className="text-white font-semibold underline hover:text-gray-200"
          >
            Register
          </Link>
        </p>
      </form>
    </div>
  );
};

export default Login;
