import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import axios from "axios";

interface UserProfile {
  name: string;
  email: string;
  joined: string;
  weight: string;
  height: string;
  age: string;
  goal: string;
}

const Profile = () => {
  const [user, setUser] = useState<UserProfile>({
    name: "",
    email: "",
    joined: "",
    weight: "",
    height: "",
    age: "",
    goal: "",
  });

  const [editMode, setEditMode] = useState(false);
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get("http://localhost:8000/api/user/profile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(res.data);
      } catch (err) {
        console.error("Failed to load profile", err);
      }
    };

    if (token) fetchProfile();
  }, [token]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUser((prev) => ({ ...prev, [name]: value }));
  };

  const getUserProperty = (field: keyof UserProfile): string => {
    return user[field];
  };

  const handleSave = async () => {
    try {
      const res = await axios.put("http://localhost:8000/api/user/profile", user, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUser(res.data);
      setEditMode(false);
      alert("Profile updated successfully!");
    } catch (err) {
      console.error("Failed to save profile", err);
      alert("Failed to save profile!");
    }
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-6 py-10">
        <h2 className="text-4xl font-bold text-center text-gray-800 dark:text-white mb-8">
          Your Profile
        </h2>

        <div className="bg-white dark:bg-gray-900 shadow-xl rounded-2xl p-8 space-y-6">
          {[
            { label: "Name", field: "name", type: "text" },
            { label: "Email", field: "email", type: "email", readonly: true },
            { label: "Member Since", field: "joined", readonly: true },
            { label: "Weight (kg)", field: "weight", type: "number" },
            { label: "Height (cm)", field: "height", type: "number" },
            { label: "Age", field: "age", type: "number" },
          ].map(({ label, field, type = "text", readonly }) => (
            <div key={field}>
              <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">{label}</label>
              {editMode && !readonly ? (
                <input
                  name={field}
                  value={getUserProperty(field as keyof UserProfile)}
                  onChange={handleChange}
                  type={type}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              ) : (
                <p className="text-lg font-medium text-gray-700 dark:text-gray-100">
                  {getUserProperty(field as keyof UserProfile)}
                </p>
              )}
            </div>
          ))}

          <div>
            <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Fitness Goal</label>
            {editMode ? (
              <select
                name="goal"
                value={user.goal}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">Select a goal</option>
                <option value="Lose Weight">Lose Weight</option>
                <option value="Build Muscle">Build Muscle</option>
                <option value="Improve Stamina">Improve Stamina</option>
                <option value="Stay Fit">Stay Fit</option>
              </select>
            ) : (
              <p className="text-lg font-medium text-gray-700 dark:text-gray-100">{user.goal}</p>
            )}
          </div>

          <div className="flex justify-end gap-4 pt-4">
            {editMode ? (
              <>
                <button
                  onClick={() => setEditMode(false)}
                  className="px-4 py-2 rounded-lg bg-gray-300 dark:bg-gray-700 hover:bg-gray-400 dark:hover:bg-gray-600 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition"
                >
                  Save
                </button>
              </>
            ) : (
              <button
                onClick={() => setEditMode(true)}
                className="px-5 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition"
              >
                Edit Profile
              </button>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
