import { useEffect, useState } from "react";
import type { WorkoutBase } from "../types/workout";
import Layout from "../components/Layout";
import axios from "axios";
import API_BASE_URL from "../config";

const WorkoutHistory = () => {
  const [workouts, setWorkouts] = useState<WorkoutBase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    fetchWorkouts();
  }, []);

  const fetchWorkouts = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setError("No authentication token found");
        setLoading(false);
        return;
      }

      const response = await axios.get(`${API_BASE_URL}/api/workout/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setWorkouts(response.data || []);
    } catch (error) {
      console.error("Error fetching workout history:", error);
      if (axios.isAxiosError(error) && error.response?.status === 401) {
        setError("Session expired. Please log in again.");
      } else {
        setError("Failed to load workout history");
      }
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6 text-gray-900 dark:text-white">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6 text-gray-900 dark:text-white">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Workout History</h2>
            <p className="text-red-500">{error}</p>
          </div>
        </div>
      </Layout>
    );
  }
  

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6 text-gray-900 dark:text-white">
        <h2 className="text-3xl font-bold mb-6 text-center">Workout History</h2>

        {workouts.length === 0 ? (
          <p className="text-center text-gray-500 dark:text-gray-400">
            No workout history found.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
              <thead>
                <tr className="bg-gray-200 dark:bg-gray-700">
                  <th className="px-6 py-3 border-b dark:border-gray-700 text-left">Date</th>
                  <th className="px-6 py-3 border-b dark:border-gray-700 text-left">Type</th>
                  <th className="px-6 py-3 border-b dark:border-gray-700 text-left">Duration</th>
                  <th className="px-6 py-3 border-b dark:border-gray-700 text-left">Calories</th>
                  <th className="px-6 py-3 border-b dark:border-gray-700 text-left">Audio Memo</th>
                </tr>
              </thead>
              <tbody>
                {workouts.map((workout, index) => (
                  <tr
                    key={index}
                    className="border-t dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition"
                  >
                    <td className="px-6 py-4">{workout.date || "N/A"}</td>
                    <td className="px-6 py-4 capitalize">{workout.type || "N/A"}</td>
                    <td className="px-6 py-4">{workout.duration ?? "0"} min</td>
                    <td className="px-6 py-4">{workout.calories ?? "0"}</td>
                    <td className="px-6 py-4">
                      {workout.audioMemo ? (
                        <audio controls className="w-36">
                          <source src={workout.audioMemo} type="audio/webm" />
                          Your browser does not support audio playback.
                        </audio>
                      ) : (
                        <span className="text-sm text-gray-500">No memo</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default WorkoutHistory;
