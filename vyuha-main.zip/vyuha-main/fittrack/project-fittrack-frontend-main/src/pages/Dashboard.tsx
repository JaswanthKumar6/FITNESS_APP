import Layout from "@/components/Layout";
import WorkoutChart from "@/components/WorkoutChart";
import AITips from "@/components/AITips";
import VoiceMemoRecorder from "@/components/VoiceMemoRecorder";
import VoiceMemoUploader from "@/components/VoiceMemoUploader";
import { useEffect, useState, useCallback } from "react";
import { Dumbbell, Flame, TimerReset, RefreshCw } from "lucide-react";
import CoachingTip from "@/components/CoachingTip";
import WorkoutSummaryChart from "../components/WorkoutSummaryChart";
import type { Workout } from "../types/workout";
import { differenceInDays, parseISO } from "date-fns";
import axios from "axios";
import API_BASE_URL from "../config";

const Dashboard = () => {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [sortBy, setSortBy] = useState<string>("");
  const [filterType, setFilterType] = useState<string>("All");
  const [aiTip, setAiTip] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");
  const [totalWorkoutsCount, setTotalWorkoutsCount] = useState<number | null>(null);

  const checkAndFetchAITip = useCallback(async (count: number) => {
    const TIP_INTERVAL = 5;
    if (count > 0 && count % TIP_INTERVAL === 0) {
      try {
        const res = await fetch(`${API_BASE_URL}/api/ai/generate-tip`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        const data = await res.json();
        if (data.tip) setAiTip(data.tip);
      } catch (err) {
        console.error("Failed to fetch AI Tip", err);
      }
    }
  }, []);

  const fetchWorkouts = async () => {
    try {
      setLoading(true);
      setError("");
      const token = localStorage.getItem("token");
      if (!token) {
        setError("Not authenticated");
        setLoading(false);
        return;
      }
      const response = await axios.get(`${API_BASE_URL}/api/workout/`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setWorkouts(response.data);
      checkAndFetchAITip(response.data.length);
    } catch (err) {
      console.error("Failed to fetch workouts:", err);
      setError("Failed to load workouts");
    } finally {
      setLoading(false);
    }
  };


  const fetchWorkoutsFromBackend = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/workout/history`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (!res.ok) throw new Error("Failed to fetch workouts");
      const data = await res.json();
      setWorkouts(data);
      localStorage.setItem("workouts", JSON.stringify(data));
      checkAndFetchAITip(data.length);
    } catch (err) {
      console.error("Failed to fetch workouts from backend", err);
    }
  }, [checkAndFetchAITip]);

  useEffect(() => {
    fetchWorkouts();
    fetchWorkoutsFromBackend();
    const fetchTotalCount = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/workout/count`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        const data = await res.json();
        setTotalWorkoutsCount(data.total_workouts);
      } catch (err) {
        console.error("Failed to fetch total workouts from backend", err);
      }
    };
    fetchTotalCount();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleDelete = async (workoutId: number) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;
      await axios.delete(`${API_BASE_URL}/api/workout/${workoutId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchWorkouts();
      // Update total workouts count after deletion
      if (totalWorkoutsCount !== null) {
        setTotalWorkoutsCount(prev => prev !== null ? prev - 1 : null);
      }
    } catch (err) {
      console.error("Failed to delete workout:", err);
      alert("Failed to delete workout");
    }
  };

  const clearAll = async () => {
    if (!confirm("Are you sure you want to delete all workouts?")) return;
    try {
      const token = localStorage.getItem("token");
      if (!token) return;
      await axios.delete(`${API_BASE_URL}/api/workout/clear`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setWorkouts([]);
      setTotalWorkoutsCount(0);
    } catch (err) {
      console.error("Failed to clear workouts:", err);
      alert("Failed to clear workouts");
    }
  };

  const handleSortChange = (criteria: string) => {
    const sorted = [...workouts];
    if (criteria === "date") {
      sorted.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } else if (criteria === "calories") {
      sorted.sort((a, b) => b.calories - a.calories);
    } else if (criteria === "duration") {
      sorted.sort((a, b) => b.duration - a.duration);
    }
    setSortBy(criteria);
    setWorkouts(sorted);
  };

  const filteredWorkouts =
    filterType === "All" ? workouts : workouts.filter((w) => w.type === filterType);

  const totalCalories = filteredWorkouts.reduce((sum, w) => sum + w.calories, 0);
  const totalDuration = filteredWorkouts.reduce((sum, w) => sum + w.duration, 0);

  const recentWorkouts = workouts.filter((w) => {
    const daysAgo = differenceInDays(new Date(), parseISO(w.date));
    return daysAgo <= 7;
  });

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-indigo-600" />
            <p className="text-gray-600">Loading your dashboard...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <p className="text-red-600 mb-4">{error}</p>
            <button
              onClick={fetchWorkouts}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
            >
              Retry
            </button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-10 px-4 sm:px-6 lg:px-0">
        <div className="flex justify-between items-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white tracking-tight">
            Your Dashboard
          </h2>
          <button
            onClick={fetchWorkouts}
            className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700 shadow">
            <div className="flex items-center gap-4">
              <Dumbbell className="text-indigo-600 w-8 h-8" />
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Total Workouts</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-white">
                  {totalWorkoutsCount !== null ? totalWorkoutsCount : workouts.length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700 shadow">
            <div className="flex items-center gap-4">
              <TimerReset className="text-green-600 w-8 h-8" />
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Total Duration</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-white">{totalDuration} mins</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl border border-gray-200 dark:border-gray-700 shadow">
            <div className="flex items-center gap-4">
              <Flame className="text-yellow-600 w-8 h-8" />
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Calories Burned</p>
                <p className="text-2xl font-bold text-gray-800 dark:text-white">{totalCalories} kcal</p>
              </div>
            </div>
          </div>
        </div>

        {workouts.length > 0 && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div>
              <label className="text-gray-700 dark:text-gray-300 font-medium mr-2">Sort By:</label>
              <select
                value={sortBy}
                onChange={(e) => handleSortChange(e.target.value)}
                className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded p-2"
              >
                <option value="">None</option>
                <option value="date">Date</option>
                <option value="calories">Calories</option>
                <option value="duration">Duration</option>
              </select>
            </div>
            <div>
              <label className="text-gray-700 dark:text-gray-300 font-medium mr-2">Filter by Type:</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded p-2"
              >
                <option value="All">All</option>
                <option value="Running">Running</option>
                <option value="Cycling">Cycling</option>
                <option value="Yoga">Yoga</option>
                <option value="Strength">Strength</option>
                <option value="Swimming">Swimming</option>
              </select>
            </div>
          </div>
        )}

        {filteredWorkouts.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow p-6">
            <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Progress Chart</h3>
            <WorkoutChart workouts={filteredWorkouts} />
          </div>
        )}

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow p-6">
          <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Workout Summary Chart</h3>
          <WorkoutSummaryChart />
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow p-6">
          <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">AI Coaching Tips</h3>
          <AITips workouts={recentWorkouts} />
        </div>

        {aiTip && (
          <div className="bg-yellow-100 text-yellow-800 p-4 rounded-xl shadow-md">
            💡 <strong>AI Coaching Tip:</strong> {aiTip}
          </div>
        )}

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow p-6">
          <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Coaching Tip</h3>
          <CoachingTip
            workouts={filteredWorkouts.map((w) => ({ date: w.date, activity: w.type, duration: w.duration }))}
          />
        </div>

        <div className="flex justify-between items-center mt-8">
          <h3 className="text-2xl font-semibold text-gray-800 dark:text-white">Recent Workouts</h3>
          {workouts.length > 0 && (
            <button onClick={clearAll} className="text-sm text-red-500 hover:underline transition">
              Clear All
            </button>
          )}
        </div>

        <div className="overflow-x-auto bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-700 shadow rounded-2xl">
          <table className="min-w-full text-sm text-left">
            <thead className="bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-300 uppercase text-xs">
              <tr>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Duration</th>
                <th className="px-6 py-4">Calories</th>
                <th className="px-6 py-4">Memo</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredWorkouts.map((w) => (
                <tr key={w.id} className="border-t dark:border-gray-700 last:border-b hover:bg-gray-50 dark:hover:bg-gray-800 transition">
                  <td className="px-6 py-4">{w.date}</td>
                  <td className="px-6 py-4">{w.type}</td>
                  <td className="px-6 py-4">{w.duration} mins</td>
                  <td className="px-6 py-4">{w.calories} kcal</td>
                  <td className="px-6 py-4">
                    {w.audioMemo ? (
                      <audio controls className="w-40">
                        <source src={w.audioMemo} type="audio/webm" />
                      </audio>
                    ) : (
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-gray-500">No memo</span>
                        <VoiceMemoRecorder
                          onSave={async (url) => {
                            try {
                              const token = localStorage.getItem("token");
                              if (!token) return;
                              await axios.put(
                                `${API_BASE_URL}/api/workout/${w.id}`,
                                { audioMemo: url },
                                { headers: { Authorization: `Bearer ${token}` } }
                              );
                              await fetchWorkouts();
                            } catch (e) {
                              console.error("Failed to attach memo", e);
                            }
                          }}
                        />
                        <VoiceMemoUploader
                          workoutId={w.id}
                          onUpload={async (url) => {
                            try {
                              const token = localStorage.getItem("token");
                              if (!token) return;
                              await axios.put(
                                `${API_BASE_URL}/api/workout/${w.id}`,
                                { audioMemo: url },
                                { headers: { Authorization: `Bearer ${token}` } }
                              );
                              await fetchWorkouts();
                            } catch (e) {
                              console.error("Failed to attach uploaded memo", e);
                            }
                          }}
                        />
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {typeof w.id === 'number' ? (
                      <button onClick={() => handleDelete(w.id)} className="text-red-500 hover:underline text-sm">
                        Delete
                      </button>
                    ) : (
                      <span className="text-xs text-gray-400">Invalid ID</span>
                    )}
                  </td>
                </tr>
              ))}
              {filteredWorkouts.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
                    No workouts yet. Log one to get started!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
