export interface Workout {
  id: number;
  date: string;
  type: string;
  duration: number;
  calories: number;
  audioMemo?: string;
}

// For components that need the activity field, we can create a mapped type
export interface WorkoutForCoaching {
  date: string;
  activity: string;
  duration: number;
}

// For components that don't need all fields (like charts and history)
export interface WorkoutBase {
  date: string;
  type: string;
  duration: number;
  calories: number;
  audioMemo?: string;
}