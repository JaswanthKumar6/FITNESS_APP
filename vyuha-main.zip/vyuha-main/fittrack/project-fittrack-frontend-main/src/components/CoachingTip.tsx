import { useEffect, useState } from "react";
import type { WorkoutForCoaching } from "../types/workout";

const API_BASE_URL = "http://localhost:8000";

interface Props {
  workouts: WorkoutForCoaching[];
}

function buildSummary(workouts: WorkoutForCoaching[]): string {
  return workouts
    .map((w) => `${w.date}: ${w.activity} for ${w.duration} mins`)
    .join("\n");
}

export default function CoachingTip({ workouts }: Props) {
  const [tip, setTip] = useState("");

  useEffect(() => {
    const shouldGenerateTip = workouts.length > 0 && workouts.length % 5 === 0;
    if (!shouldGenerateTip) return;

    const token = localStorage.getItem("token");
    if (!token) {
      console.warn("No token found. Skipping coaching tip generation.");
      return;
    }

    const recentWorkouts = workouts.slice(-5);
    const summary = buildSummary(recentWorkouts);

    localStorage.setItem("loWorkouts", JSON.stringify(recentWorkouts));

    fetch(`${API_BASE_URL}/api/ai/generate-tip`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ summary }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.tip) {
          setTip(data.tip);
        } else {
          console.error("No tip received:", data);
        }
      })
      .catch((error) => {
        console.error("Error fetching coaching tip:", error);
      });
  }, [workouts]);

  if (!tip) return null;

  return (
    <div className="p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-900 rounded shadow mb-4">
      <p className="font-semibold">AI Coaching Tip:</p>
      <p>{tip}</p>
    </div>
  );
}
