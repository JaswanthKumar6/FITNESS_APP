import { useRef, useState, useEffect } from "react";
import axios from "axios";
import API_BASE_URL from "../config";

interface Props {
  workoutId: number;
  onUpload: (url: string) => void;
}

const VoiceMemoUploader = ({ workoutId, onUpload }: Props) => {
  const [recording, setRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploadToBackend = async (blob: Blob) => {
    try {
      const formData = new FormData();
      formData.append("audio", blob, "voice_memo.webm");

      const response = await axios.post(`${API_BASE_URL}/api/audio/upload`, formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      if (response.status === 200 && (response.data?.full_url || response.data?.file_url)) {
        onUpload(response.data.full_url || response.data.file_url);
      } else {
        console.error("Upload failed:", response);
        alert("Failed to upload audio.");
      }
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      console.error("Error uploading audio:", error);
      alert(`Error uploading audio: ${errorMessage}`);
    }
  };

  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunks.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunks.current, { type: "audio/webm" });
        uploadToBackend(audioBlob);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      alert("Microphone access denied.");
    }
  };

  const handleStopRecording = () => {
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    uploadToBackend(file);
  };

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== "inactive"
      ) {
        mediaRecorderRef.current.stop();
        const stream = mediaRecorderRef.current.stream;
        if (stream) {
          stream.getTracks().forEach((track) => track.stop());
        }
      }
    };
  }, []);

  return (
    <div className="space-x-2">
      {recording ? (
        <button
          onClick={handleStopRecording}
          className="px-2 py-1 bg-red-600 text-white rounded text-xs"
        >
          Stop
        </button>
      ) : (
        <button
          onClick={handleStartRecording}
          className="px-2 py-1 bg-blue-600 text-white rounded text-xs"
        >
          Record
        </button>
      )}

      <button
        onClick={() => fileInputRef.current?.click()}
        className="text-blue-500 text-xs underline"
      >
        Upload File
      </button>

      <input
        type="file"
        accept="audio/*"
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileUpload}
      />
    </div>
  );
};

export default VoiceMemoUploader;
