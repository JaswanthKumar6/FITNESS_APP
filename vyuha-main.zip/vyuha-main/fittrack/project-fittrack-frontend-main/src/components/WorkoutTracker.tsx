import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from 'chart.js';
import axios from 'axios';
import API_BASE_URL from '../config';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

interface WorkoutStats {
  type: string;
  totalDuration: number;
  totalCalories: number;
  count: number;
}

const WorkoutTracker: React.FC = () => {
  const [stats, setStats] = useState<WorkoutStats[]>([]);
  const [view, setView] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        setError("");
        const token = localStorage.getItem('token');
        if (!token) {
          setError("User not authenticated");
          setLoading(false);
          return;
        }

        const res = await axios.get(`${API_BASE_URL}/api/workout/stats?view=${view}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStats(res.data || []);
      } catch (err: unknown) {
        console.error("Failed to fetch workout stats", err);
        setError(err instanceof Error ? err.message : "Failed to fetch stats");
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [view]);

  const labels = stats.map((s) => s.type.toUpperCase());

  const chartData = {
    labels,
    datasets: [
      {
        label: 'Duration (mins)',
        data: stats.map((s) => s.totalDuration),
        backgroundColor: 'rgba(59, 130, 246, 0.7)',
      },
      {
        label: 'Calories Burned',
        data: stats.map((s) => s.totalCalories),
        backgroundColor: 'rgba(234, 88, 12, 0.7)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: { color: '#1f2937' },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: { color: '#4b5563' },
      },
      x: {
        ticks: { color: '#4b5563' },
      },
    },
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">
          Workout Summary ({view})
        </h2>
        <select
          className="border border-gray-300 rounded px-2 py-1"
          value={view}
          onChange={(e) => setView(e.target.value as 'daily' | 'weekly' | 'monthly')}
        >
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
      </div>

      {loading ? (
        <p className="text-gray-600">Loading...</p>
      ) : error ? (
        <p className="text-red-500">{error}</p>
      ) : stats.length === 0 ? (
        <p className="text-gray-500">No data available for selected view.</p>
      ) : (
        <Bar data={chartData} options={options} />
      )}
    </div>
  );
};

export default WorkoutTracker;
