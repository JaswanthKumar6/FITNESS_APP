import { useRef, useState } from "react";
import API_BASE_URL from "../config";

interface VoiceMemoRecorderProps {
  onSave: (url: string) => void;
}

const VoiceMemoRecorder: React.FC<VoiceMemoRecorderProps> = ({ onSave }) => {
  const [recording, setRecording] = useState(false);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState("");
  const [audioUrl, setAudioUrl] = useState("");
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);

  const startRecording = async () => {
    setError("");
    setSuccess("");
    setAudioUrl("");

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunks.current = [];

      mediaRecorderRef.current.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunks.current.push(e.data);
        }
      };

      mediaRecorderRef.current.onstop = async () => {
        setRecording(false);
        const audioBlob = new Blob(audioChunks.current, { type: "audio/webm" });

        // Stop microphone
        stream.getTracks().forEach((track) => track.stop());

        // Upload the audio file
        await uploadAudio(audioBlob);
      };

      mediaRecorderRef.current.start();
      setRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      setError("Microphone access denied. Please allow access.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current?.state === "recording") {
      mediaRecorderRef.current.stop();
    }
  };

  const uploadAudio = async (blob: Blob) => {
    const token = localStorage.getItem("token");

    if (!token) {
      setError("Authentication required.");
      return;
    }

    const formData = new FormData();
    formData.append("audio", blob, "voice_memo.webm");

    try {
      setUploading(true);

      const response = await fetch(`${API_BASE_URL}/api/audio/upload`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      const result = await response.json();

      if (!response.ok) {
        console.error("Upload failed:", result);
        throw new Error(result?.error || "Upload failed.");
      }

      console.log("Upload success:", result);
      setSuccess("Audio uploaded successfully.");
      setAudioUrl(result.full_url);

      // ✅ Call parent callback
      onSave(result.full_url);
    } catch (err: unknown) {
      console.error("Upload error:", err);
      const errorMessage = err instanceof Error ? err.message : "Unknown error occurred";
      setError("Failed to upload audio. " + errorMessage);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col items-start gap-3 mt-4">
      {error && <p className="text-red-500 text-sm">{error}</p>}
      {success && <p className="text-green-600 text-sm">{success}</p>}
      {uploading && <p className="text-blue-600 text-sm">Uploading...</p>}

      {!recording ? (
        <button
          onClick={startRecording}
          className="bg-blue-600 text-white py-1 px-3 rounded hover:bg-blue-700"
        >
          🎙️ Start Recording
        </button>
      ) : (
        <button
          onClick={stopRecording}
          className="bg-red-600 text-white py-1 px-3 rounded hover:bg-red-700"
        >
          ⏹️ Stop Recording
        </button>
      )}

      {audioUrl && (
        <audio controls className="mt-3">
          <source src={audioUrl} type="audio/webm" />
          Your browser does not support the audio element.
        </audio>
      )}
    </div>
  );
};

export default VoiceMemoRecorder;
