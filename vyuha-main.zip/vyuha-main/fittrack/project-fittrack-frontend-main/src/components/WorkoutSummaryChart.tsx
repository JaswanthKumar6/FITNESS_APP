import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import axios from "axios";
import API_BASE_URL from "../config";
import * as htmlToImage from "html-to-image";
import download from "downloadjs";

interface SummaryData {
  date: string;
  total_duration: number;
  total_calories: number;
}

const WorkoutSummaryChart = () => {
  const [data, setData] = useState<SummaryData[]>([]);
  const [view, setView] = useState<"weekly" | "monthly">("weekly");
  const [isDark, setIsDark] = useState(false);
  const navigate = useNavigate();

  // Sync dark mode
  useEffect(() => {
    const darkQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const updateTheme = (e: MediaQueryListEvent) => setIsDark(e.matches);
    setIsDark(darkQuery.matches);
    darkQuery.addEventListener("change", updateTheme);
    return () => darkQuery.removeEventListener("change", updateTheme);
  }, []);

  // Fetch chart data
  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login");
      return;
    }

    const fetchData = async () => {
      try {
        const res = await axios.get(
          `${API_BASE_URL}/api/summary/chart?view=${view}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setData(res.data);
      } catch (err) {
        console.error("Failed to fetch summary chart data:", err);
        if (axios.isAxiosError(err) && err.response?.status === 401) {
          localStorage.removeItem("token");
          navigate("/login");
        }
      }
    };

    fetchData();
  }, [view, navigate]);

  // Export as CSV
  const exportCSV = () => {
    const header = "Date,Duration (min),Calories\n";
    const csv = data.map((row) => `${row.date},${row.total_duration},${row.total_calories}`).join("\n");
    const blob = new Blob([header + csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "workout_summary.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export as PNG
  const exportPNG = () => {
    const chartEl = document.querySelector(".recharts-wrapper") as HTMLElement | null;
    if (!chartEl) {
      console.error("Chart element not found");
      return;
    }

    htmlToImage.toPng(chartEl)
      .then((dataUrl) => download(dataUrl, "workout_summary.png"))
      .catch((err) => console.error("Image export failed:", err));
  };

  return (
    <div className="rounded-2xl p-4 shadow-md w-full max-w-4xl mx-auto bg-white text-black dark:bg-gray-900 dark:text-white transition-colors duration-300">
      <div className="flex justify-between items-center mb-4 relative">
        <h2 className="text-xl font-semibold text-center w-full">Workout Summary</h2>
        <div className="flex gap-2 absolute right-6">
          <button
            onClick={() => setView("weekly")}
            className={`px-3 py-1 rounded-lg text-sm ${
              view === "weekly" ? "bg-blue-500 text-white" : "bg-gray-200 dark:bg-gray-700 dark:text-white"
            }`}
          >
            Weekly
          </button>
          <button
            onClick={() => setView("monthly")}
            className={`px-3 py-1 rounded-lg text-sm ${
              view === "monthly" ? "bg-blue-500 text-white" : "bg-gray-200 dark:bg-gray-700 dark:text-white"
            }`}
          >
            Monthly
          </button>
        </div>
      </div>

      {data.length > 0 ? (
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={data}>
            <CartesianGrid stroke={isDark ? "#444" : "#e0e0e0"} strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fill: isDark ? "#ccc" : "#333" }} />
            <YAxis
              yAxisId="left"
              label={{
                value: "Duration (min)",
                angle: -90,
                position: "insideLeft",
                fill: isDark ? "#ccc" : "#333",
              }}
              tick={{ fill: isDark ? "#ccc" : "#333" }}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              label={{
                value: "Calories",
                angle: -90,
                position: "insideRight",
                fill: isDark ? "#ccc" : "#333",
              }}
              tick={{ fill: isDark ? "#ccc" : "#333" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: isDark ? "#1f2937" : "#fff",
                border: "1px solid #ccc",
                color: isDark ? "#fff" : "#000",
              }}
            />
            <Legend wrapperStyle={{ color: isDark ? "#fff" : "#000" }} />
            <Bar
              yAxisId="left"
              dataKey="total_duration"
              fill={isDark ? "#6366f1" : "#8884d8"}
              name="Duration (min)"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="total_calories"
              stroke={isDark ? "#34d399" : "#82ca9d"}
              strokeWidth={3}
              name="Calories"
            />
          </ComposedChart>
        </ResponsiveContainer>
      ) : (
        <p className="text-center mt-6 text-gray-600 dark:text-gray-300">
          No data available for this view.
        </p>
      )}

      <div className="mt-6 flex justify-center gap-4">
        <button
          onClick={exportCSV}
          className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm"
        >
          Export CSV
        </button>
        <button
          onClick={exportPNG}
          className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg text-sm"
        >
          Save Image
        </button>
      </div>
    </div>
  );
};

export default WorkoutSummaryChart;
