import React from "react";
import { differenceInDays, parseISO } from "date-fns";
import type { Workout } from "../types/workout";

interface AITipsProps {
  workouts: Workout[];
}

const AITips: React.FC<AITipsProps> = ({ workouts }) => {
  if (workouts.length === 0) {
    return (
      <p className="text-gray-500">
        Start logging workouts to get personalized AI tips!
      </p>
    );
  }

  const tips: string[] = [];
  const latest = workouts[workouts.length - 1];

  const latestDate = parseISO(latest.date);
  const daysSinceLastWorkout = differenceInDays(new Date(), latestDate);

  // ⏳ Inactivity Tip
  if (daysSinceLastWorkout >= 3) {
    tips.push(`It's been ${daysSinceLastWorkout} days since your last workout. Time to get moving!`);
  }

  // ⏱ Duration Tip
  if (latest.duration < 20) {
    tips.push("Try increasing your workout duration to at least 30 minutes for better impact.");
  } else if (latest.duration > 60) {
    tips.push("You’re pushing long sessions—make sure to get enough rest and fuel!");
  } else {
    tips.push("Great job keeping your sessions at a healthy length.");
  }

  // 🔥 Calories Tip
  if (latest.calories < 100) {
    tips.push("Consider increasing the intensity to boost your calorie burn.");
  } else if (latest.calories > 500) {
    tips.push("Impressive effort! Make sure you’re recovering properly.");
  } else {
    tips.push("Solid calorie burn—keep it consistent!");
  }

  // ⚖️ Balance Tip
  const recentTypes = workouts.slice(-5).map((w) => w.type.toLowerCase());
  const strengthCount = recentTypes.filter((t) => t.includes("strength")).length;
  const cardioCount = recentTypes.filter((t) => t.includes("cardio") || t.includes("run") || t.includes("walk")).length;

  if (strengthCount > cardioCount + 1) {
    tips.push("You're focusing heavily on strength—add some cardio to improve heart health.");
  } else if (cardioCount > strengthCount + 1) {
    tips.push("Cardio is great! Try some strength workouts to build muscle and support metabolism.");
  } else {
    tips.push("Nice balance between cardio and strength workouts!");
  }

  // 🔁 Streak Tip
  const workoutDates = workouts
    .map((w) => parseISO(w.date))
    .sort((a, b) => +b - +a);

  let streak = 1;
  for (let i = 1; i < workoutDates.length; i++) {
    const diff = differenceInDays(workoutDates[i - 1], workoutDates[i]);
    if (diff === 1) streak++;
    else break;
  }
  if (streak >= 3) {
    tips.push(`Awesome! You're on a ${streak}-day workout streak.`);
  }

  // 💧 General Tip
  tips.push("Don't forget to hydrate well before and after your workouts.");

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md mt-4">
      <h3 className="text-lg font-semibold mb-2 text-gray-800 dark:text-gray-100">💡 AI Tips</h3>
      <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-200">
        {tips.map((tip, idx) => (
          <li key={idx}>{tip}</li>
        ))}
      </ul>
    </div>
  );
};

export default AITips;
