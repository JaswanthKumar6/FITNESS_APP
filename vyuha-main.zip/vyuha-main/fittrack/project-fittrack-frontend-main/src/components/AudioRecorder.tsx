import { useState, useRef } from "react";

interface AudioRecorderProps {
  workoutId: number;
  token: string;
  onUpload: () => void; // optional callback after successful upload
}

const AudioRecorder: React.FC<AudioRecorderProps> = ({
  workoutId,
  token,
  onUpload,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(
    null
  );
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioChunks = useRef<Blob[]>([]);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    setMediaRecorder(recorder);
    audioChunks.current = [];

    recorder.ondataavailable = (e) => {
      audioChunks.current.push(e.data);
    };

    recorder.onstop = () => {
      const audioBlob = new Blob(audioChunks.current, { type: "audio/webm" });
      const url = URL.createObjectURL(audioBlob);
      setAudioUrl(url);
    };

    recorder.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    mediaRecorder?.stop();
    setIsRecording(false);
  };

  const uploadAudio = async () => {
    if (!audioChunks.current.length) return;

    const audioBlob = new Blob(audioChunks.current, { type: "audio/webm" });
    const formData = new FormData();
    formData.append("audio", audioBlob, "voice_note.webm");

    try {
      const res = await fetch(`http://localhost:5000/api/audio/upload/${workoutId}`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!res.ok) {
        const error = await res.text();
        throw new Error(error);
      }

      if (onUpload) onUpload();
      alert("Voice memo uploaded!");
    } catch (err) {
      console.error("Upload failed:", err);
      alert("Failed to upload audio.");
    }
  };

  return (
    <div className="flex flex-col items-center gap-2 p-4 border rounded-xl shadow bg-white">
      <button
        onClick={isRecording ? stopRecording : startRecording}
        className={`px-4 py-2 rounded text-white ${
          isRecording ? "bg-red-500" : "bg-green-500"
        }`}
      >
        {isRecording ? "Stop Recording" : "Start Recording"}
      </button>

      {audioUrl && (
        <>
          <audio controls src={audioUrl} className="mt-2" />
          <button
            onClick={uploadAudio}
            className="bg-blue-600 px-4 py-2 rounded text-white mt-2"
          >
            Upload Audio
          </button>
        </>
      )}
    </div>
  );
};

export default AudioRecorder;
