// src/components/WorkoutChart.tsx

import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import type { WorkoutBase } from '../types/workout';

interface WorkoutChartProps {
  workouts: WorkoutBase[];
}

const WorkoutChart: React.FC<WorkoutChartProps> = ({ workouts }) => {
  const chartData = useMemo(() => {
    return workouts
      .map((w) => ({
        date: new Date(w.date).toISOString().slice(5, 10), // format: MM-DD
        calories: w.calories,
      }))
      .sort((a, b) => a.date.localeCompare(b.date)); // ensure proper chronological order
  }, [workouts]);

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-md border border-gray-200 dark:border-gray-700">
      <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
        Calories Burned Over Time
      </h3>
      {chartData.length > 0 ? (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" stroke="#8884d8" />
            <YAxis
              stroke="#8884d8"
              label={{
                value: "Calories",
                angle: -90,
                position: "insideLeft",
                offset: 10,
                style: { textAnchor: "middle", fill: "#8884d8" },
              }}
            />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="calories"
              stroke="#6366F1"
              strokeWidth={3}
              dot={{ r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <p className="text-gray-500 dark:text-gray-300">
          No workout data available.
        </p>
      )}
    </div>
  );
};

export default WorkoutChart;
