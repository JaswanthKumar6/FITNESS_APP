import AppRoutes from './router';

function App() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <AppRoutes />
    </div>
  );
}

export default App;
