# FitTrackk – Full-Stack Fitness Tracking Application

## 🎯 Project Objective

FitTrackk helps users log workouts, view workout history, track progress, and manage workout types. It includes a user-facing system and an admin dashboard.

---

## 🖼️ Frontend (Client-Side)

### 📌 Tech Stack
- **React.js** (TypeScript)
- **Vite**
- **Tailwind CSS**
- **React Router**
- **Axios**
- **LocalStorage** (for JWT)

### 📁 Pages/Components
- Login / Register
- Dashboard
- Workout Log
- Workout History
- Workout Summary Chart (Export as CSV/Image)
- Profile
- Admin Dashboard (Workout Type Management)
- Protected Routes
- Layout with Navbar

### 🔐 Features
- Token-based authentication (JWT)
- Protected routes
- Admin role support
- Data export (CSV/Image)
- Responsive UI

---

## 🛠️ Backend (Server-Side)

### 📌 Tech Stack
- **Flask (Python)**
- **Flask-JWT-Extended**
- **Flask-CORS**
- **SQLite3** (default, can migrate to PostgreSQL/MySQL)

### 📁 Endpoints

#### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/profile`

#### Workout
- `POST /api/workouts`
- `GET /api/workouts`
- `GET /api/workouts/summary`
- `DELETE /api/workouts/<id>`

#### Admin - Workout Types
- `POST /api/workout-types`
- `GET /api/workout-types`

---

## 🗃️ Database Schema

### Tables

#### `users`
- `id`, `name`, `email`, `password_hash`, `is_admin`

#### `workouts`
- `id`, `user_id`, `type`, `duration`, `date`, `notes`

#### `workout_types`
- `id`, `name`

### Authentication
- JWT stored in LocalStorage
- Protected routes require `Authorization: Bearer <token>`

---

## 📊 Chart & Export

- **Recharts** for data visualization
- Buttons to export:
  - CSV
  - Image

---

## 🧪 API Testing

- **Postman** used to test all backend endpoints

---

## 🔄 Workflow

1. Login → Backend returns JWT
2. JWT stored in LocalStorage
3. Protected routes accessed with token
4. Workout data saved/retrieved from SQLite3
5. Charts generated from backend summary endpoint

---

## ✅ Admin Features

- Add/Delete workout types from `/admin-dashboard`
- Users can select these when logging workouts

---

## 🧠 Technologies Summary

| Layer         | Technology |
|---------------|------------|
| Frontend      | React, TypeScript, Vite, Tailwind, Axios, React Router |
| Backend       | Flask, Flask-JWT-Extended, Flask-CORS |
| Database      | SQLite3 |
| Auth          | JWT |
| Charts        | Recharts |
| Export        | CSV, Image |

---

## 📌 Future Enhancements

- Use PostgreSQL in production
- Add password reset
- Editable user profile
- Social features (follow others)
- Hosting:
  - Backend: Render / Railway
  - Frontend: Vercel / Netlify
